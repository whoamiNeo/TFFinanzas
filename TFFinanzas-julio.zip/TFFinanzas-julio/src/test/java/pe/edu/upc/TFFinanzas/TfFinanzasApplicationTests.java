package pe.edu.upc.TFFinanzas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfFinanzasApplicationTests {

	@Test
	void contextLoads() {
	}

}
