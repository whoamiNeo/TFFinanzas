package pe.edu.upc.TFFinanzas.entities;
public enum TipoCreditoEnum {
    CORTO_PLAZO,
    LARGO_PLAZO
}
