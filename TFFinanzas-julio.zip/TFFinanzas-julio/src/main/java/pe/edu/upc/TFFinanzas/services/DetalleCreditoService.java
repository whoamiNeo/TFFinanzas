package pe.edu.upc.TFFinanzas.services;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;;
import org.springframework.stereotype.Service;
import pe.edu.upc.TFFinanzas.dtos.DetalleCreditoDTO;
import pe.edu.upc.TFFinanzas.entities.DetalleCredito;
import pe.edu.upc.TFFinanzas.repositories.DetalleCreditoRepository;
import pe.edu.upc.TFFinanzas.repositories.CreditoRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DetalleCreditoService {
    private final DetalleCreditoRepository detalleCreditoRepository;

    @Autowired
    private CreditoRepository creditoRepository;

    public List<DetalleCreditoDTO> listarDetallesPorCredito(Long idCredito) {
        List<DetalleCredito> detalles = detalleCreditoRepository.findByCreditoIdCredito(idCredito);
        return detalles.stream()
                .map(detalle -> new DetalleCreditoDTO(
                        detalle.getIdDetalleCredito(),
                        detalle.getSaldoInicial(),
                        detalle.getInteres(),
                        detalle.getRenta(),
                        detalle.getAmortizacion(),
                        detalle.getSaldoFinal(),
                        detalle.getFechaPagoCuota(),
                        detalle.isEstadoPago(),
                        detalle.getMora(),
                        detalle.getCredito().getIdCredito()))
                .collect(Collectors.toList());
    }


    //CAMBIO MANUAL(para usar en controller)
    //Contiene la lógica de actualización y persistencia de DetalleCredito y Credito
    //y se asegura de que los cambios en ambas entidades persistan en la base de datos
    @Transactional
    public DetalleCredito updateEstadoPago(Long id, boolean estadoPago) {
        DetalleCredito detalleCredito = detalleCreditoRepository.findById(id).
                orElseThrow(() -> new RuntimeException("DetalleCredito no encontrado"));
        detalleCredito.setEstadoPago(estadoPago);
        // Guardar cambios en Credito y DetalleCredito
        creditoRepository.save(detalleCredito.getCredito());
        return detalleCreditoRepository.save(detalleCredito);
    }


    //CAMBIO AUTOMATICO
    //Actualiza el "estadoPago" de "DetalleCredito" y "estado" de "Credito" automáticamente
    @Transactional
    public void actualizarEstadoPagoAutomaticamente(Long id, boolean estadoPago) {
        DetalleCredito detalleCredito = detalleCreditoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("DetalleCredito no encontrado"));
        detalleCredito.setEstadoPagoPago(estadoPago);
        creditoRepository.save(detalleCredito.getCredito());
        detalleCreditoRepository.save(detalleCredito);
    }

}
