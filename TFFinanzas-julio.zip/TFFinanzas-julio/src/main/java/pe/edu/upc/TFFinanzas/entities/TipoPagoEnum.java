package pe.edu.upc.TFFinanzas.entities;

public enum TipoPagoEnum {
    VISA,
    MASTERCARD,
    YAPE,
    EFECTIVO
}
