package pe.edu.upc.TFFinanzas.entities;

public enum RoleEnum {
    ADMIN, USER
}
