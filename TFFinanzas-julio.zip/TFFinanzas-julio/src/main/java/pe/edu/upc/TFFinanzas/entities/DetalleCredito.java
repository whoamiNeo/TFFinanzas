package pe.edu.upc.TFFinanzas.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "detalle_credito")
public class DetalleCredito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDetalleCredito;
    private Float saldoInicial;
    private Float interes;
    private Float renta;
    private Float amortizacion;
    private Float saldoFinal;
    private LocalDate fechaPagoCuota;
    private boolean estadoPago;
    private Float mora;
    

    @ManyToOne
    @JoinColumn(name = "idCredito", nullable = false)
    private Credito credito;
    
    @OneToMany(mappedBy = "detalleCredito", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Pago> pagos;

/*
    //Modifica el setEstadoPago para actualizar el "estado" del Credito al que está relacionado
    //Así cada vez que se cambie el "estadoPago" el estado de Credito también se cambiará
    public void setEstadoPago(boolean estadoPago) {
        this.estadoPago = estadoPago;
        if (this.credito != null) {
            this.credito.setEstado(estadoPago);
        }
    }

 */


    //Modifica el setEstadoPago para actualizar el "estado" del Credito al que está relacionado
    //Así cada vez que se cambie el "estadoPago" el estado de Credito también se cambiará
    //Pero solo cambiará el "estado" de Credito si todos los "estadoPago" de los DetalleCredito relacionados
    //a ese Credito estan en "true"
    public void setEstadoPago(boolean estadoPago) {
        this.estadoPago = estadoPago;
        if (this.credito != null) {
            if (estadoPago) {
                // Verifica si todos los pagos relacionados a este credito están en true
                boolean allPagosTrue = this.credito.getDetalleCreditos().stream()
                        .allMatch(detalleCredito -> detalleCredito.isEstadoPago());

                // Solo si todos los estadoPago están en true cambiará el estado del Credito a true
                if (allPagosTrue) {
                    this.credito.setEstado(true);
                }
            } else {
                this.credito.setEstado(false);
            }
        }
    }


    public void setEstadoPagoPago(boolean estadoPago){

    }

}
