package pe.edu.upc.TFFinanzas.entities;

public enum TipoInteresEnum {
    NOMINAL,
    EFECTIVO,
    ANUALIDAD_SIMPLE
}